<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';
entity_detail_page('treatments');
