<?php
declare(strict_types=1);

function h(?string $v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); }

function redirect(string $to, int $code = 302): void {
    header('Location: ' . $to, true, $code);
    exit;
}

function client_ip(): string {
    $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
    return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '';
}

function base_url(): string {
    if (SITE_URL !== '') {
        return rtrim(SITE_URL, '/');
    }
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    return ($https ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
}
function abs_url(string $path = '/'): string { return base_url() . '/' . ltrim($path, '/'); }

/** Versioned static asset URL (cache-busting by file mtime). */
function asset(string $path): string {
    $file = WEB_ROOT . '/' . ltrim($path, '/');
    $v = is_file($file) ? (string) filemtime($file) : '1';
    return '/' . ltrim($path, '/') . '?v=' . $v;
}

/** Public URL for an uploaded/stored image; falls back to a placeholder so no <img> is ever broken. */
function img_url(?string $path, string $fallback = '/assets/img/placeholder.svg'): string {
    $path = trim((string) $path);
    if ($path !== '') {
        if (preg_match('#^https?://#i', $path)) {
            return $path;
        }
        $p = '/' . ltrim($path, '/');
        if (is_file(WEB_ROOT . strtok($p, '?'))) {
            return $p;
        }
    }
    return $fallback;
}

/**
 * Responsive WebP renditions of an image: ['400' => url, '800' => url, '1600' => url], or [] when they do not exist.
 * Uploads that were stored before this system get their renditions created on first use (once).
 */
function img_variants(string $url): array {
    $path = strtok($url, '?') ?: '';
    if (preg_match('#^/(uploads|assets/img)/([A-Za-z0-9._-]+)\.(?:jpe?g|png|webp|gif)$#i', $path, $m) !== 1) {
        return [];
    }
    $dirPart = $m[1];
    $name = $m[2];
    $base = WEB_ROOT . '/' . $dirPart . '/' . $name;
    $generated = preg_match('/-(400|800|1600)$/', $name) === 1; // already a rendition: never make renditions of renditions
    $have = static fn(): bool => array_reduce(IMG_VARIANT_WIDTHS, static fn(bool $ok, int $w) => $ok && is_file($base . '-' . $w . '.webp'), true);
    // Renditions are rebuilt when the source file is newer than them (a replaced photo must not keep its old WebP).
    $src = $base . '.' . strtolower((string) pathinfo($path, PATHINFO_EXTENSION));
    $stale = false;
    if ($dirPart === 'uploads' && !$generated && $have() && is_file($src)) {
        $oldest = min(array_map(static fn(int $w): int => (int) @filemtime($base . '-' . $w . '.webp'), IMG_VARIANT_WIDTHS));
        $stale = (int) @filemtime($src) > $oldest;
    }
    if ((!$have() || $stale) && $dirPart === 'uploads' && !$generated) {
        try {
            make_webp_variants($src, $base);
        } catch (Throwable $e) {
            error_log('[jebu] img_variants: ' . $e->getMessage());
        }
    }
    if (!$have()) {
        return [];
    }
    $out = [];
    foreach (IMG_VARIANT_WIDTHS as $w) {
        $out[(string) $w] = '/' . $dirPart . '/' . $name . '-' . $w . '.webp';
    }
    return $out;
}

/**
 * Responsive <picture>: WebP srcset (400/800/1600 w) with the original as the fallback <img>.
 * Pass 0 for width/height to read the real size of the file (keeps layout stable, no CLS).
 * Only images that are not the LCP image should be lazy; pass $lazy = false for the hero photo.
 */
function img_picture(string $url, string $alt, int $width = 0, int $height = 0, string $sizes = '100vw', bool $lazy = true, string $extra = ''): string {
    if ($alt === '' && str_starts_with($url, '/uploads/')) {
        $alt = img_alt_for($url); // admin's alt text (or the auto one from the title)
    }
    if ($width <= 0 || $height <= 0) {
        $file = WEB_ROOT . strtok($url, '?');
        $dim = is_file($file) ? @getimagesize($file) : false;
        if ($dim) {
            [$width, $height] = [$dim[0], $dim[1]];
        }
    }
    $img = '<img src="' . h($url) . '" alt="' . h($alt) . '"'
        . ($width > 0 ? ' width="' . $width . '" height="' . $height . '"' : '')
        . ' decoding="async"' . ($lazy ? ' loading="lazy"' : '') . $extra . '>';
    $v = img_variants($url);
    if (!$v) {
        return $img;
    }
    // Do not offer renditions wider than the real image (keeps the srcset honest); keep at least the smallest
    $set = [];
    foreach ($v as $w => $u) {
        if ($width > 0 && (int) $w > $width && $set !== []) {
            break;
        }
        $set[] = h($u) . ' ' . $w . 'w';
    }
    return '<picture><source type="image/webp" srcset="' . implode(', ', $set) . '" sizes="' . h($sizes) . '">' . $img . '</picture>';
}

// ---------------- Settings ----------------
function settings_all(): array {
    // Kept in a global so save_setting() can update it: a value saved in this request is read back at once.
    if (isset($GLOBALS['settings_cache'])) {
        return $GLOBALS['settings_cache'];
    }
    $cache = site_defaults();
    try {
        sec_migrate_settings(); // one-time: plain-text secrets become encrypted rows
        foreach (q_all('SELECT skey, svalue FROM site_settings') as $r) {
            if ($r['svalue'] !== '') {
                $cache[$r['skey']] = sec_is_secret_setting((string) $r['skey'])
                    ? sec_decrypt((string) $r['svalue'])
                    : $r['svalue'];
            }
        }
    } catch (Throwable $e) {
        // DB not ready: fall back to defaults so the page can still render
    }
    $GLOBALS['settings_cache'] = $cache;
    return $cache;
}
function setting(string $key, string $default = ''): string {
    $s = settings_all();
    return isset($s[$key]) ? (string) $s[$key] : $default;
}
function setting_lines(string $key): array {
    return array_values(array_filter(array_map('trim', preg_split('/\R/u', setting($key)) ?: []), static fn($l) => $l !== ''));
}
function setting_paras(string $key): array {
    return array_values(array_filter(array_map('trim', preg_split('/\R{2,}/u', setting($key)) ?: []), static fn($l) => $l !== ''));
}
function save_setting(string $key, string $value): void {
    $plain = $value;
    if (sec_is_secret_setting($key)) {
        $value = sec_encrypt($value); // secrets are never stored in plain text
    }
    $exists = q_val('SELECT COUNT(*) FROM site_settings WHERE skey = ?', [$key]);
    if ((int) $exists > 0) {
        q_exec('UPDATE site_settings SET svalue = ?, updated_at = ? WHERE skey = ?', [$value, date('Y-m-d H:i:s'), $key]);
    } else {
        q_exec('INSERT INTO site_settings (skey, svalue) VALUES (?, ?)', [$key, $value]);
    }
    // Keep this request's cache in step with the database (plain value; secrets are decrypted for reads).
    if (isset($GLOBALS['settings_cache'])) {
        $GLOBALS['settings_cache'][$key] = $plain;
    }
}

function phone_digits(string $s): string {
    $s = strtr($s, ['০' => '0', '১' => '1', '২' => '2', '৩' => '3', '৪' => '4', '৫' => '5', '৬' => '6', '৭' => '7', '৮' => '8', '৯' => '9']);
    return preg_replace('/[^0-9+]/', '', $s) ?? '';
}
function tel_link(): string { return 'tel:+' . preg_replace('/\D/', '', setting('whatsapp_intl')); }
function wa_link(string $msg = ''): string {
    $u = 'https://wa.me/' . preg_replace('/\D/', '', setting('whatsapp_intl'));
    return $msg !== '' ? $u . '?text=' . rawurlencode($msg) : $u;
}

// ---------------- Text rendering ----------------
function inline_md(string $s): string {
    $s = h($s);
    $s = preg_replace('/\*\*(.+?)\*\*/s', '<strong>$1</strong>', $s) ?? $s;
    $s = preg_replace_callback('/\[([^\]]+)\]\((\/[^)\s]*|https?:\/\/[^)\s]+)\)/', static function ($m) {
        $ext = str_starts_with($m[2], 'http');
        return '<a href="' . $m[2] . '"' . ($ext ? ' rel="noopener nofollow" target="_blank"' : '') . '>' . $m[1] . '</a>';
    }, $s) ?? $s;
    return $s;
}

/** Tiny safe Markdown subset: ## / ### headings, - lists, **bold**, [links](url), paragraphs. */
function md(?string $text): string {
    $text = trim((string) $text);
    if ($text === '') {
        return '';
    }
    $blocks = preg_split('/\R{2,}/u', $text) ?: [];
    $out = '';
    foreach ($blocks as $b) {
        $b = trim($b);
        if ($b === '') {
            continue;
        }
        if (str_starts_with($b, '### ')) { $out .= '<h3>' . inline_md(substr($b, 4)) . '</h3>'; continue; }
        if (str_starts_with($b, '## '))  { $out .= '<h2>' . inline_md(substr($b, 3)) . '</h2>'; continue; }
        // A block that is only an image: ![alt](/uploads/file.jpg) or ![alt](https://...)
        if (preg_match('/^!\[([^\]]*)\]\(((?:\/|https:\/\/)[^)\s]+)\)$/u', $b, $im) === 1) {
            $out .= '<figure class="inline-img">' . img_picture($im[2], $im[1], 0, 0, '(max-width:720px) 100vw, 720px') . '</figure>';
            continue;
        }
        $lines = preg_split('/\R/u', $b) ?: [];
        $isList = count($lines) > 0 && count(array_filter($lines, static fn($l) => preg_match('/^\s*[-*•]\s+/u', $l) === 1)) === count($lines);
        if ($isList) {
            $out .= '<ul>';
            foreach ($lines as $l) {
                $out .= '<li>' . inline_md(preg_replace('/^\s*[-*•]\s+/u', '', $l) ?? $l) . '</li>';
            }
            $out .= '</ul>';
            continue;
        }
        $out .= '<p>' . nl2br(inline_md($b), false) . '</p>';
    }
    return $out;
}

function md_blocks(string $text): array {
    return array_values(array_filter(array_map('trim', preg_split('/\R{2,}/u', trim($text)) ?: [])));
}

function reading_minutes(string $text): int {
    $plain = strip_tags($text);
    $words = preg_match_all('/[\p{L}\p{N}]+/u', $plain);
    return max(1, (int) ceil(((int) $words) / 180));
}

function trim_text(string $s, int $len): string {
    $s = trim(preg_replace('/\s+/u', ' ', strip_tags($s)) ?? '');
    return mb_strlen($s) > $len ? rtrim(mb_substr($s, 0, $len - 1)) . '…' : $s;
}

/** Like trim_text(), but cuts at a word boundary when one is near the limit (used for <title>). */
function trim_words(string $s, int $len): string {
    $s = trim(preg_replace('/\s+/u', ' ', strip_tags($s)) ?? '');
    if (mb_strlen($s) <= $len) {
        return $s;
    }
    $cut = mb_substr($s, 0, $len - 1);
    $sp = mb_strrpos($cut, ' ');
    if ($sp !== false && $sp >= (int) ($len * 0.6)) {
        $cut = mb_substr($cut, 0, $sp);
    }
    return rtrim($cut, " |,:;-") . '…';
}

function slugify(string $s): string {
    $s = strtolower(trim($s));
    $s = preg_replace('/[^a-z0-9]+/', '-', $s) ?? '';
    return trim($s, '-');
}

function bn_date(?string $dt): string {
    if (!$dt) {
        return '';
    }
    $t = strtotime($dt);
    if (!$t) {
        return '';
    }
    $months = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
    $s = (int) date('j', $t) . ' ' . $months[(int) date('n', $t) - 1] . ', ' . date('Y', $t);
    return strtr($s, ['0' => '০', '1' => '১', '2' => '২', '3' => '৩', '4' => '৪', '5' => '৫', '6' => '৬', '7' => '৭', '8' => '৮', '9' => '৯']);
}
/** "১৫+" / "15+" / "২০০" -> [15, '+'] ; no digits -> [0, ''] */
function stat_parse(string $raw): array {
    $ascii = strtr($raw, ['০' => '0', '১' => '1', '২' => '2', '৩' => '3', '৪' => '4', '৫' => '5', '৬' => '6', '৭' => '7', '৮' => '8', '৯' => '9']);
    if (preg_match('/\d+/', $ascii, $m) !== 1) { return [0, '']; }
    return [(int) $m[0], str_contains($ascii, '+') ? '+' : ''];
}

function bn_num(int|string $n): string {
    return strtr((string) $n, ['0' => '০', '1' => '১', '2' => '২', '3' => '৩', '4' => '৪', '5' => '৫', '6' => '৬', '7' => '৭', '8' => '৮', '9' => '৯']);
}

// ---------------- CSRF / form tokens ----------------
/** Stateless signed token for public forms (no cookie needed): "<ts>.<hmac>". */
function form_token(): string {
    $ts = (string) time();
    return $ts . '.' . hash_hmac('sha256', 'form|' . $ts, APP_KEY);
}
function form_token_ok(string $tok, int $minAge = 2, int $maxAge = 7200): bool {
    if (!preg_match('/^(\d{9,11})\.([a-f0-9]{64})$/', $tok, $m)) {
        return false;
    }
    if (!hash_equals(hash_hmac('sha256', 'form|' . $m[1], APP_KEY), $m[2])) {
        return false;
    }
    $age = time() - (int) $m[1];
    return $age >= $minAge && $age <= $maxAge;
}

// ---------------- Logging ----------------
function log_activity(string $action, string $detail = '', ?int $userId = null): void {
    try {
        q_exec('INSERT INTO activity_log (user_id, action, detail, ip) VALUES (?,?,?,?)', [$userId, mb_substr($action, 0, 120), mb_substr($detail, 0, 500), client_ip()]);
    } catch (Throwable $e) {
        // never break the request because of logging
    }
}
function log_404(): void {
    try {
        $url = mb_substr((string) ($_SERVER['REQUEST_URI'] ?? ''), 0, 500);
        $ref = mb_substr((string) ($_SERVER['HTTP_REFERER'] ?? ''), 0, 500);
        $ua = mb_substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 300);
        $n = q_exec('UPDATE not_found_log SET hits = hits + 1, last_seen = ?, referrer = ?, user_agent = ? WHERE url = ?', [date('Y-m-d H:i:s'), $ref, $ua, $url]);
        if ($n === 0) {
            q_exec('INSERT INTO not_found_log (url, referrer, user_agent) VALUES (?,?,?)', [$url, $ref, $ua]);
        }
    } catch (Throwable $e) {
    }
}

function indexnow_ping(string $url): void {
    if (INDEXNOW_KEY === '' || !function_exists('curl_init')) {
        return;
    }
    $host = parse_url($url, PHP_URL_HOST);
    if (!$host) {
        return;
    }
    $ch = curl_init('https://api.indexnow.org/indexnow');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode(['host' => $host, 'key' => INDEXNOW_KEY, 'keyLocation' => 'https://' . $host . '/' . INDEXNOW_KEY . '.txt', 'urlList' => [$url]]),
        CURLOPT_HTTPHEADER => ['Content-Type: application/json; charset=utf-8'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 3,
        CURLOPT_CONNECTTIMEOUT => 2,
    ]);
    @curl_exec($ch);
    curl_close($ch);
}

function json_ld(array $data): string {
    return '<script type="application/ld+json">' . json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) . '</script>';
}

/** Line icon for a specialty, chosen from its slug (gynaecology-focused). Falls back to a female-health symbol. */
function specialty_icon_svg(string $slug): string {
    $icons = [
        // pregnancy / antenatal care: mother with a round belly
        'antenatal-delivery-care' => '<circle cx="12" cy="4.5" r="2"/><path d="M9.5 21.5v-6.2c0-2.6 1.2-4.6 2.5-4.6s2.5 2 2.5 4.6v6.2"/><circle cx="12" cy="13.2" r="3.2"/>',
        // fertility: seedling
        'fertility-management' => '<path d="M12 21v-9"/><path d="M12 12c0-4 3-7 7.5-7 0 4.2-3.2 7-7.5 7z"/><path d="M12 14.5c0-3-2.4-5.3-6-5.3 0 3 2.5 5.3 6 5.3z"/>',
        // gynaecological surgery: surgical kit
        'gynaecological-surgery' => '<rect x="3.5" y="8" width="17" height="12" rx="2"/><path d="M9 8V5.5h6V8"/><path d="M12 11.5v5M9.5 14h5"/>',
        // menstrual health: calendar with drop
        'menstrual-health' => '<rect x="4" y="5" width="16" height="15" rx="2.5"/><path d="M4 10h16M9 3v4M15 3v4"/><path d="M12 12.6c-1.1 1.5-1.8 2.5-1.8 3.4a1.8 1.8 0 0 0 3.6 0c0-.9-.7-1.9-1.8-3.4z"/>',
        // breast care: heart
        'breast-care' => '<path d="M12 20s-7.5-4.6-7.5-10.1A4.2 4.2 0 0 1 12 7.4a4.2 4.2 0 0 1 7.5 2.5C19.5 15.4 12 20 12 20z"/>',
        // lifespan women's care: female symbol
        'lifespan-womens-care' => '<circle cx="12" cy="9" r="5"/><path d="M12 14v7M9 18.5h6"/>',
    ];
    $body = $icons[$slug] ?? '<circle cx="12" cy="9" r="5"/><path d="M12 14v7M9 18.5h6"/>';
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $body . '</svg>';
}


/** Active chambers, in owner's serial order. */
function chamber_rows(): array {
    static $rows = null;
    if ($rows === null) {
        try { $rows = localize_rows(q_all('SELECT * FROM chambers WHERE is_active = 1 ORDER BY sort_order ASC, id ASC')); }
        catch (Throwable $e) { $rows = []; }
    }
    return $rows;
}

/** Map link for a chamber: owner's link first, otherwise a Google Maps search from name + location (no API key). */
function chamber_map_link(array $c): string {
    $link = trim((string) ($c['map_link'] ?? ''));
    if (preg_match('#^https://#i', $link) === 1) { return $link; }
    $q = trim((string) ($c['name'] ?? '') . ', ' . (string) ($c['location'] ?? ''), ', ');
    return $q === '' ? '' : 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode($q);
}

/** Chamber cards (serial badge, name, location, hours, phone, map). Empty string when no chambers are set. */
function chamber_cards_html(): string {
    $rows = chamber_rows();
    if (!$rows) { return ''; }
    $out = '<div class="chamber-grid">';
    foreach ($rows as $c) {
        $map = chamber_map_link($c);
        $out .= '<article class="chamber-card reveal">'
            . '<span class="ch-no" aria-label="' . h(tr('সিরিয়াল ', 'Serial ')) . (int) $c['sort_order'] . '">' . h(site_lang() === 'en' ? (string) (int) $c['sort_order'] : bn_num((int) $c['sort_order'])) . '</span>'
            . '<h3>' . h((string) $c['name']) . '</h3>';
        if (trim((string) $c['location']) !== '') { $out .= '<p class="ch-loc">' . nl2br(h((string) $c['location']), false) . '</p>'; }
        if (trim((string) $c['visiting_hours']) !== '') { $out .= '<p><b>' . h(tr('সময়:', 'Hours:')) . '</b> ' . h((string) $c['visiting_hours']) . '</p>'; }
        if (trim((string) $c['phone']) !== '') { $out .= '<p><b>' . h(tr('ফোন:', 'Phone:')) . '</b> <a href="tel:' . h(preg_replace('/[^0-9+]/', '', (string) $c['phone'])) . '">' . h((string) $c['phone']) . '</a></p>'; }
        if ($map !== '') { $out .= '<a class="ch-map" href="' . h($map) . '" target="_blank" rel="noopener">' . h(tr('ম্যাপে দেখুন ↗', 'View on map ↗')) . '</a>'; }
        $out .= '</article>';
    }
    return $out . '</div>';
}
